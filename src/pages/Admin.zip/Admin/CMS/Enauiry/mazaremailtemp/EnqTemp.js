import React from "react";
const EnqTemp = () => {
  return (
    <>
      <p>Prateek</p>
    </>
  );
};
export default EnqTemp;
